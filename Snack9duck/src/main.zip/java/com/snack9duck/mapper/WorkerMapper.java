package com.snack9duck.mapper;



import com.snack9duck.domain.WorkerVO;



public interface WorkerMapper {

	
	public WorkerVO adminLogin(WorkerVO worker);
	
}
