package com.snack9duck.service;





import com.snack9duck.domain.WorkerVO;



public interface WorkerService {

	public WorkerVO adminLogin(WorkerVO worker);
}
