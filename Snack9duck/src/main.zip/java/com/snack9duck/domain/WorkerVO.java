package com.snack9duck.domain;


import lombok.Data;

@Data
public class WorkerVO {
	private String workerid;
	private String workerpwd;
	private String name;
	
}
